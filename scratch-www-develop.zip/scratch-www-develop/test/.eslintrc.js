module.exports = {
    extends: ['scratch/react'],
    env: {
        jest: true
    }
};
