// __mocks__/react-responsive.js

const MediaQuery = ({children}) => children;

export default MediaQuery;
