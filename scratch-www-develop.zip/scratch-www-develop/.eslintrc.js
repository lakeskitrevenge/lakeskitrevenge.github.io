module.exports = {
    extends: ['scratch', 'scratch/node'],
    plugins: ['json']
};
