
_Describe the problem. Please make sure you can reproduce the bug. It's also
helpful to include screenshots or animated gifs of the problem._

### Steps to Reproduce

_Explain what someone needs to do in order to see what's described above. The 
more detailed and explicit the steps are the better._

### Operating System and Browser

_e.g. Mac OS 10.11.6 Safari 10.0_
